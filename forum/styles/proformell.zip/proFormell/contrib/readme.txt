MMMdddddddddddddddmmMMMMNddddddddddmNMMMmdddddddddmNMMMmddddddddddmMMM
MMM-----------------sMMMy-----------/mMM/----------+NMh:----------:MMM
MMM..shhhhh:.ohhhy..:MMMmhhhhhhhhhh..dMM/.+hhhhhh-..NMo./hhhhhhhhhhMMM
MMM--mMMMMM/-yMMMN--:MMMNhsssssssss--dMM/-yMMMMMMyssNMo-oMMMMMMMMMMMMM
MMM--mMMMMM/-yMMMN--/MMMh:-::::::::--dMM/-yMMMMMMMMMMMo-oMMMMMMMMMMMMM
MMM--mMMMMM/-hMMMN--/MMMy-/mmmmmmmm--dMM/-yMMMMMMMMMMMo-oNNNNNNNNNNMMM
MMM--mMMMMM/-hMMMN--/MMMh::++++++++--mMM+-yMMMMMMMMMMMs::++++++++++MMM
MMMooNMMMMMsodMMMNoosMMMNhooooooooooomMMyodMMMMMMMMMMMmsoooooooooosMMM


Thank you for downloading this style.
If you like it please consider donating, even one euro will help a lot. More information on my homepage.

Homepage:
http://www.m-a-styles.de

How to install a style:
http://www.phpbb.com/kb/article/how-to-install-styles-on-phpbb3/


***********************************************************************

Translators Information:

The font used in the big buttons is Arial Bold and the font size is 12pt.
icon_post_quote.gif and icon_post_edit.gif both use Arial Bold and the 
font size is 5pt. Font color is #bc2a4d and anti-aliasing is used 
("Strong" in Photoshop).

***********************************************************************

Some copyright information:

Borders partially made with Shoots's Guide to Styling Prosilver
